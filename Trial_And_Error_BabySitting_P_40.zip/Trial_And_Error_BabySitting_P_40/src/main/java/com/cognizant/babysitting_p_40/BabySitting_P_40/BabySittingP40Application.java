package com.cognizant.babysitting_p_40.BabySitting_P_40;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com")
public class BabySittingP40Application {

	public static void main(String[] args) {
		SpringApplication.run(BabySittingP40Application.class, args);
	}

}
