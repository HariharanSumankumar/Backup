package com.cognizant.babysitting_p_40.controller;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;


import org.springframework.stereotype.Controller;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



import com.cognizant.babysitting_p_40.model.Student;


@Controller
public class EnrollmentController {
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public String showhomepage(@ModelAttribute("stud") Student stud) {    //model attribute binds the form to stud
	  
	return "homepage";      // directs to enroll.jsp page   at first i direct to the enroll.jsp page

	}
	@RequestMapping("/login")
	public String login(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_LOGIN");
		return "homepage";
	}
	
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public String showEnrollpage(@ModelAttribute("stud") Student stud) {    //model attribute binds the form to stud
	  
	return "enroll";      // directs to enroll.jsp page   at first i direct to the enroll.jsp page

	}


	@RequestMapping(value="/login-successful-bs-search", method=RequestMethod.GET)
	public String checkSuccessDetails(@Valid@ModelAttribute("stud") Student stud,BindingResult result) {    //model attribute binds the form to stud    //result of validation is at result and that result is used to check for errors here down below
//		System.out.println(stud.toString());
		
	if(result.hasErrors())
	{
		return "enroll";
	}
	else
	{
		return "search";     ///if there isn't ,then it goes to success page
	} 

	}
	@RequestMapping(value="/paymentprocess", method=RequestMethod.GET)
	public String checkSuccessDetails2(@Valid@ModelAttribute("stud") Student stud,BindingResult result1) {    //model attribute binds the form to stud    //result of validation is at result and that result is used to check for errors here down below

	  
		System.out.println(stud.toString());
		  return "payment";     ///if there isn't ,then it goes to success page
		 	 

	}
	@RequestMapping(value="/paymentsuccessprocess", method=RequestMethod.POST)
	public String checkSuccessDetails3(@Valid@ModelAttribute("stud") Student stud,BindingResult result2) {    //model attribute binds the form to stud    //result of validation is at result and that result is used to check for errors here down below


		  return "success";     ///if there isn't ,then it goes to success page
	}
}
