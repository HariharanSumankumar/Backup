package com.cognizant.babysitting_p_40.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.*;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;

public class Student {

	public Student() {
	}
	@Size(min = 3, max = 12, message = "*User Name must be between 3 and 12 characters long")
	private String userName;
	
	

	@Size(min = 3, max = 30, message = "*First Name must be between 3 and 30 characters long")   ///Checking for First Name to be of 3 to 30 characters
	private String firstName;
	
	@Size(min = 3, max = 30, message = "*Last Name must be between 3 and 30 characters long")     ///Checking for Last Name to be of 3 to 30 characters
	private String lastName;
	
	
	
	@NotNull(message="Date must not be blank")     					///Date should be specified 
	@DateTimeFormat(pattern = "dd/MM/yyyy")      					///Checking for the Date Pattern
	@Past(message="*Date should be past")       					///Date should be mentioned in Past 
	private Date dob;
	
	@NotNull(message = "*Email cannot be blank")					///Email id should be specified
	private String email;
	

	private String password;
	

	//	@NotNull(message="*Please specify your selection") 
	private String selection;
	
	private String card;
	
	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	
	public String getCard() {
		return card;
	}

	public void setCard(String card) {
		this.card = card;
	}

	public String getSelection() {
		return selection;
	}

	public void setSelection(String selection) {
		this.selection = selection;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
