package com.cognizant.babysitting_p_40.BabySitting_P_40;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabySittingP40ApplicationTests {

	@Test
	void contextLoads() {
	}

}
